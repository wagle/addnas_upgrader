#!/bin/sh
if [ $# != 1 ]; then
	exit 4
fi
case $1 in
one)	exit 1
	;;
two)	exit 2
	;;
*)	exit 3
	;;
esac
